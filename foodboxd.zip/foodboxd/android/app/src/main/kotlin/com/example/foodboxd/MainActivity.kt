package com.example.foodboxd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
