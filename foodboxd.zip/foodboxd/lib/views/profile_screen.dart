import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:foodboxd/views/edit_profile_screen.dart';
import 'package:foodboxd/views/login_screen.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Map<String, dynamic>? userDetails;

  @override
  void initState() {
    super.initState();
    _fetchUserDetails();
  }

  Future<void> _fetchUserDetails() async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        final snapshot = _firestore.collection('users').doc(user.uid).snapshots();

        snapshot.listen((e) {
          if (mounted) {
            setState(() {
              userDetails = e.data();
            });
          }
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error fetching user details: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text("User Profile"),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              FirebaseAuth.instance.signOut();
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
            },
          ),
        ],
      ),
      body: userDetails == null
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // Display profile picture
                  Center(
                    child: userDetails?['profileImageUrl'] != null
                        ? CircleAvatar(
                            radius: 50,
                            backgroundImage: NetworkImage(userDetails!['profileImageUrl']),
                          )
                        : const CircleAvatar(
                            radius: 50,
                            child: Icon(Icons.person, size: 50),
                          ),
                  ),
                  const SizedBox(height: 20),

                  // Display user details
                  ListTile(
                    title: const Text("Name"),
                    subtitle: Text(userDetails?['name'] ?? "N/A"),
                  ),
                  ListTile(
                    title: const Text("Email"),
                    subtitle: Text(user?.email ?? "N/A"),
                  ),
                  ListTile(
                    title: const Text("Phone Number"),
                    subtitle: Text(userDetails?['phone'] ?? "N/A"),
                  ),
                  ListTile(
                    title: const Text("Date of Birth"),
                    subtitle: Text(userDetails?['dob'] ?? "N/A"),
                  ),
                  ListTile(
                    title: const Text("Username"),
                    subtitle: Text(userDetails?['username'] ?? "N/A"),
                  ),
                  const SizedBox(height: 20),

                  // Edit Profile Button
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => EditProfileScreen(
                            userDetails: userDetails!,
                            onSave: _fetchUserDetails,
                          ),
                        ),
                      );
                    },
                    child: const Text("Edit Profile"),
                  ),
                ],
              ),
            ),
    );
  }
}
