import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class EditProfileScreen extends StatefulWidget {
  final Map<String, dynamic> userDetails;
  final VoidCallback onSave;

  const EditProfileScreen({required this.userDetails, required this.onSave, super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  final _formKey = GlobalKey<FormState>();

  late TextEditingController nameController;
  late TextEditingController phoneController;
  late TextEditingController dateOfBirthController;
  late TextEditingController usernameController;

  String? _profileImageUrl; // To store the existing profile image URL
  File? _selectedImageFile; // To store the locally selected image file
  bool _isLoading = false; // Loading state

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.userDetails['name']);
    phoneController = TextEditingController(text: widget.userDetails['phone']);
    dateOfBirthController = TextEditingController(text: widget.userDetails['dob']);
    usernameController = TextEditingController(text: widget.userDetails['username']);
    _profileImageUrl = widget.userDetails['profileImageUrl']; // Load existing profile image URL
  }

  Future<void> _pickImage() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.image);
      if (result != null) {
        setState(() {
          _selectedImageFile = File(result.files.single.path!);
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error selecting image: $e")));
    }
  }

  Future<void> _saveChanges() async {
    if (_formKey.currentState?.validate() ?? false) {
      final user = _auth.currentUser;
      if (user != null) {
        setState(() => _isLoading = true); // Show loading indicator

        try {
          // Upload image if a new one is selected
          String? downloadUrl = _profileImageUrl; // Use existing URL if no new image is selected
          if (_selectedImageFile != null) {
            final ref = _storage.ref().child('profile_images/${user.uid}');
            await ref.putFile(_selectedImageFile!);
            downloadUrl = await ref.getDownloadURL();
          }

          // Save updated details to Firestore
          await _firestore.collection('users').doc(user.uid).update({
            'name': nameController.text,
            'phone': phoneController.text,
            'dob': dateOfBirthController.text,
            'username': usernameController.text,
            'profileImageUrl': downloadUrl, // Save the profile image URL
          });

          widget.onSave(); // Refresh the profile screen
          Navigator.pop(context);
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error saving changes: $e")));
        } finally {
          setState(() => _isLoading = false); // Hide loading indicator
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Edit Profile")),
      body: Align(
        alignment: Alignment.center,
        child: SizedBox(
          width: 600,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  // Display current or default profile picture with edit icon
                  Center(
                    child: Stack(
                      clipBehavior: Clip.none,
                      alignment: Alignment.center,
                      children: [
                        CircleAvatar(
                          radius: 50,
                          backgroundImage: _selectedImageFile != null
                              ? FileImage(_selectedImageFile!)
                              : (_profileImageUrl != null ? NetworkImage(_profileImageUrl!) : null) as ImageProvider?,
                          child: _selectedImageFile == null && _profileImageUrl == null
                              ? const Icon(Icons.camera_alt, size: 50)
                              : null,
                        ),
                        Positioned(
                          bottom: -5,
                          right: -5,
                          child: GestureDetector(
                            onTap: _pickImage,
                            child: CircleAvatar(
                              radius: 15,
                              backgroundColor: Colors.orange,
                              child: const Icon(Icons.edit, size: 15, color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: "Name"),
                    validator: (value) => value!.isEmpty ? "Name cannot be empty" : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: phoneController,
                    decoration: const InputDecoration(labelText: "Phone Number"),
                    keyboardType: TextInputType.phone,
                    validator: (value) => value!.isEmpty ? "Phone number cannot be empty" : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: dateOfBirthController,
                    decoration: const InputDecoration(labelText: "Date of Birth"),
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(1900),
                        lastDate: DateTime.now(),
                      );
                      if (pickedDate != null) {
                        dateOfBirthController.text = pickedDate.toLocal().toString().split(' ')[0];
                      }
                    },
                    readOnly: true,
                    validator: (value) => value!.isEmpty ? "Date of birth cannot be empty" : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: usernameController,
                    decoration: const InputDecoration(labelText: "Username"),
                    validator: (value) => value!.isEmpty ? "Username cannot be empty" : null,
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _saveChanges,
                      child: Text(_isLoading ? "Wait" : "Save Changes"),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
