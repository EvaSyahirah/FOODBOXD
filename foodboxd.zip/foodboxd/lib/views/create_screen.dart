import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class CreateEntryScreen extends StatefulWidget {
  const CreateEntryScreen({super.key});

  @override
  CreateEntryScreenState createState() => CreateEntryScreenState();
}

class CreateEntryScreenState extends State<CreateEntryScreen> {
  final TextEditingController dateController = TextEditingController();
  final TextEditingController dayController = TextEditingController();
  final TextEditingController placeController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  File? _imageFile;
  bool _isLoading = false; // Track loading state

  Future<void> _pickImage() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      withData: true,
      allowCompression: true,
      type: FileType.image,
    );

    if (result != null) {
      setState(() {
        _imageFile = File(result.files.single.path!);
      });
    } else {
      // User canceled the picker
    }
  }

  Future<String?> _uploadImage(File file) async {
    try {
      final storageRef = FirebaseStorage.instance.ref().child('entries/${DateTime.now().toIso8601String()}');
      final uploadTask = await storageRef.putFile(file);
      return await uploadTask.ref.getDownloadURL();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Image upload failed: $e")));
      return null;
    }
  }

  Future<void> _saveEntry() async {
    if (dateController.text.isEmpty ||
        placeController.text.isEmpty ||
        descriptionController.text.isEmpty ||
        _imageFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("All fields are required")));
      return;
    }

    setState(() {
      _isLoading = true; // Set loading state to true
    });

    String? imageUrl;
    if (_imageFile != null) {
      imageUrl = await _uploadImage(_imageFile!);
    }

    final uid = FirebaseAuth.instance.currentUser!.uid;
    final entryData = {
      "uid": uid,
      "date": dateController.text,
      "day": dayController.text,
      "place": placeController.text,
      "description": descriptionController.text,
      "imageUrl": imageUrl ?? "",
    };

    try {
      await FirebaseFirestore.instance.collection('entries').add(entryData);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Entry saved successfully!")));

      // Clear the form fields
      setState(() {
        dateController.clear();
        dayController.clear();
        placeController.clear();
        descriptionController.clear();
        _imageFile = null;
        _isLoading = false; // Reset loading state
      });
    } catch (e) {
      setState(() {
        _isLoading = false; // Reset loading state if an error occurs
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Failed to save entry: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Entry")),
      body: Align(
        alignment: Alignment.center,
        child: SizedBox(
          width: 600,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                TextFormField(
                  controller: dateController,
                  decoration: const InputDecoration(labelText: "Date"),
                  onTap: () async {
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime.now(),
                    );
                    if (pickedDate != null) {
                      dateController.text = pickedDate.toLocal().toString().split(' ')[0];
                      dayController.text = pickedDate.weekday.toString();
                    }
                  },
                  readOnly: true,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: dayController,
                  decoration: const InputDecoration(labelText: "Day"),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: placeController,
                  decoration: const InputDecoration(labelText: "Place"),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: descriptionController,
                  decoration: const InputDecoration(labelText: "Description"),
                  maxLines: 5,
                ),
                const SizedBox(height: 16),
                const SizedBox(height: 20),
                InkWell(
                  onTap: _pickImage,
                  child: Container(
                    height: 150,
                    width: double.infinity,
                    color: Colors.blueGrey,
                    child: _imageFile != null
                        ? Image.file(_imageFile!, fit: BoxFit.cover)
                        : const Center(child: Text("Tap to add an image")),
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _saveEntry,
                    child: Text(_isLoading ? "Wait" : "Save Entry"),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
