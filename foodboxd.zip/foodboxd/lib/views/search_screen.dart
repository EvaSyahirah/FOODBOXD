import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  SearchScreenState createState() => SearchScreenState();
}

class SearchScreenState extends State<SearchScreen> {
  final TextEditingController dateController = TextEditingController();
  List<Map<String, dynamic>> filteredResults = []; // To store filtered search results
  late Stream<QuerySnapshot> _myStream; // Firestore stream to fetch entries in real-time

  @override
  void initState() {
    super.initState();
    final uid = FirebaseAuth.instance.currentUser!.uid;
    // Initialize Firestore stream to listen for real-time updates
    _myStream = FirebaseFirestore.instance
        .collection('entries')
        .where('uid', isEqualTo: uid) // Only fetch entries of the logged-in user
        .snapshots();
  }

  // Filter results based on date input
  void _searchLocally() {
    if (dateController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please enter a date")));
      return;
    }

    // Trigger a re-build to apply the date filter
    setState(() {});
  }

  // Clear search input and reset filtered results
  void _clearSearch() {
    setState(() {
      dateController.clear();
      filteredResults = []; // Show all entries again
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Search Entries")),
      body: Container(
        width: 600,
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Date input field with clear suffix icon
            TextFormField(
              controller: dateController,
              decoration: InputDecoration(
                labelText: "Enter Date to Search",
                suffixIcon: dateController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: _clearSearch,
                      )
                    : null,
              ),
              onTap: () async {
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: DateTime.now(),
                );
                if (pickedDate != null) {
                  dateController.text = pickedDate.toLocal().toString().split(' ')[0];
                  _searchLocally();
                }
              },
              readOnly: true,
            ),
            const SizedBox(height: 20),

            // Real-time StreamBuilder for listening to Firestore changes
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: _myStream, // Use the initialized stream here
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return Center(child: Text("Error: ${snapshot.error}"));
                  }

                  // Get all entries from Firestore
                  final allEntries = snapshot.data!.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();

                  // Filter results based on the date input by the user
                  if (dateController.text.isNotEmpty) {
                    filteredResults = allEntries.where((entry) => entry['date'] == dateController.text).toList();
                  } else {
                    filteredResults = allEntries; // Show all entries if no date filter
                  }

                  return filteredResults.isEmpty
                      ? const Center(child: Text("No results found"))
                      : ListView.builder(
                          itemCount: filteredResults.length,
                          itemBuilder: (context, index) {
                            final entry = filteredResults[index];
                            return Card(
                              child: ListTile(
                                title: Text(entry['place']),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(entry['description']),
                                    Text(entry['date']),
                                  ],
                                ),
                                trailing: entry['imageUrl'] != null && entry['imageUrl'] != ""
                                    ? Image.network(entry['imageUrl'], width: 50, height: 50, fit: BoxFit.cover)
                                    : null,
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        title: Text(entry['place']),
                                        content: SizedBox(
                                          width: 500,
                                          child: SingleChildScrollView(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text("Date: ${entry['date']}"),
                                                const SizedBox(height: 8),
                                                Text("Day: ${entry['day']}"),
                                                const SizedBox(height: 8),
                                                Text("Description: ${entry['description']}"),
                                                const SizedBox(height: 8),
                                                entry['imageUrl'] != null && entry['imageUrl'] != ""
                                                    ? Image.network(entry['imageUrl'], fit: BoxFit.cover)
                                                    : const Text("No image available"),
                                              ],
                                            ),
                                          ),
                                        ),
                                        actions: [
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            child: const Text("Close"),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                },
                              ),
                            );
                          },
                        );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
